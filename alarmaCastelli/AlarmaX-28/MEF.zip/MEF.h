#ifndef MEF_H
#define MEF_H
#include <Arduino.h>
#include <contrasenia.h>
class MEF
{
public:
	MEF();
	
};
#ifndef CONTRASENIA_H
#define CONTRASENIA_H

#include <Arduino.h>
class contrasenia
{
public:
	contrasenia();
	void setContraseniaNueva(char tecla);
	
};